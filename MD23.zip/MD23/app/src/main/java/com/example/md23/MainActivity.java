package com.example.md23;

package com.example.md23;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnTime, btnDate, btnName, btnBrowser, btnGPS, btnCamera;
    TextView etLName,tvName;
    EditText etURL;
    ImageView ivPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnTime = findViewById(R.id.btnTime);
        btnDate = findViewById(R.id.btnDate);
        btnName = findViewById(R.id.btnName);
        etLName = findViewById(R.id.etLName);
        tvName = findViewById(R.id.tvName);
        btnBrowser = findViewById(R.id.btnBrowser);
        etURL = findViewById(R.id.etURL);
        btnGPS = findViewById(R.id.btnGPS);
        btnCamera = findViewById(R.id.btnCamera);
        ivPhoto = findViewById(R.id.ivPhoto);

        btnTime.setOnClickListener(this);
        btnDate.setOnClickListener(this);
        btnName.setOnClickListener(this);
        btnBrowser.setOnClickListener(this);
        btnGPS.setOnClickListener(this);
        btnCamera.setOnClickListener(this);
    }

    public void onClick(View v) {
        Intent intent;
        switch(v.getId()) {
            case R.id.btnName:
                intent = new Intent(this, NameActivity.class);
                startActivityForResult(intent, 1);

                break;
            case R.id.btnBrowser:
                String url = etURL.getText().toString();
                if (!url.startsWith("https://") && !url.startsWith("http://")){
                    url = "http://" + url;
                }
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
                break;
            case R.id.btnGPS:
                startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                break;
            case R.id.btnCamera:
                Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //try{
                startActivityForResult(takePhotoIntent, 2);
                // }catch (ActivityNotFoundException e){
                //e.printStackTrace();
                //}

                break;
            default:
                intent = new Intent();
                switch (v.getId()) {
                    case R.id.btnTime:
                        intent.setAction("com.nikita.intent.action.showtime");
                        break;
                    case R.id.btnDate:
                        intent.setAction("com.nikita.intent.action.showdate");
                        break;
                }
                intent.putExtra("lname", etLName.getText().toString());
                startActivity(intent);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) { return; }
        switch (requestCode) {
            case 1:
                String name = data.getStringExtra("name");
                tvName.setText("Your name is " + name);
                break;
            case 2:
                if (resultCode == RESULT_OK) {
                    Bundle extras = data.getExtras();
                    Bitmap thumbnailBitmap = (Bitmap) extras.get("data");
                    ivPhoto.setImageBitmap(thumbnailBitmap);
                }
                break;
        }
    }

}