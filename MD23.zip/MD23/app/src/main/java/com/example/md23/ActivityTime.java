package com.example.md23;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ActivityTime extends AppCompatActivity implements View.OnTouchListener {

    FrameLayout llyt;
    TextView tvTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String time = sdf.format(new Date(System.currentTimeMillis()));

        tvTime = findViewById(R.id.tvTime);
        tvTime.setText(time);
        llyt = findViewById(R.id.timeLayout);
        llyt.setOnTouchListener(this);

    }


    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        startActivityForResult(new Intent("com.example.md23.action.color_gravity"), 1);
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {return;};

        int grvt = Gravity.CLIP_HORIZONTAL;
        String clr = "#000080";
        String color = data.getStringExtra("color");
        String gravity = data.getStringExtra("gravity");
        switch (color) {
            case "Green":
                clr = "#008000";
                break;
            case "Black":
                clr = "#000000";
                break;
            case "Red":
                clr = "#FF0000";
                break;
            case "Yellow":
                clr = "#FFFF00";
                break;
            default:
                break;
        }
        switch (gravity) {
            case "Left":
                grvt = Gravity.LEFT | Gravity.CENTER_VERTICAL;
                break;
            case "Right":
                grvt = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
                break;
            case "Top":
                grvt = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                break;
            case "Bottom":
                grvt = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                break;
            case "Center":
                grvt = Gravity.CENTER;
                break;
            default:
                break;
        }

        tvTime.setTextColor(Color.parseColor(clr));
//        tvTime.setGravity(grvt);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.gravity = grvt;
        tvTime.setLayoutParams(params);

    }
}